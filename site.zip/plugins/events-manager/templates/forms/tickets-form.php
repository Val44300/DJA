<?php
//DEPRECATED, now only using event/bookings-ticket-form.php 